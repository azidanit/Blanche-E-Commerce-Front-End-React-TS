import { Image } from 'antd';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { capitalizeFirstLetter } from '../../../../../helpers/capitalizeFirstLetter';
import {
  dateToDayMonthStringYear,
  dateToMinuteHourMonthStringDayYear,
} from '../../../../../helpers/parseDate';
import { IRefundRequest } from '../../../../../helpers/types/refund.interface';
import { Card, Tag } from '../../../../atoms';
import style from './index.module.scss';

interface RefundItemProps {
  refund: IRefundRequest;
}

const mapStatusToColor = {
  'waiting for seller approval': 'orange',
  'waiting for admin approval': 'orange',
  refunded: 'green',
  rejected: 'red',
};

const RefundItem: React.FC<RefundItemProps> = ({ refund }) => {
  const [status, setStatus] = useState('waiting');

  useEffect(() => {
    if (refund.refund_request_statuses.length === 1) {
      if (
        refund.refund_request_statuses[0].rejected_by_seller_at &&
        refund.refund_request_statuses[0].rejected_by_admin_at
      ) {
        setStatus('rejected');
      }
      if (
        refund.refund_request_statuses[0].accepted_by_seller_at &&
        refund.refund_request_statuses[0].accepted_by_admin_at
      ) {
        setStatus('refunded');
      }
      if (
        !refund.refund_request_statuses[0].accepted_by_seller_at &&
        !refund.refund_request_statuses[0].rejected_by_seller_at
      ) {
        setStatus('waiting for seller approval');
      }
      if (
        refund.refund_request_statuses[0].accepted_by_admin_at &&
        !refund.refund_request_statuses[0].rejected_by_admin_at
      ) {
        setStatus('waiting for admin approval');
      }
    }
  }, [status, refund]);

  return (
    <Card className={style.ti}>
      <div className={style.ti__header}>
        <p className={style.ti__header__title}>Request Refund</p>

        <div className={style.ti__header__date}>
          <Tag
            className={style.ct__header__tag}
            color={mapStatusToColor[status as keyof typeof mapStatusToColor]}
          >
            {capitalizeFirstLetter(status)}
          </Tag>
          <p>
            {dateToMinuteHourMonthStringDayYear(
              new Date(refund.created_at),
              ' ',
            )}
          </p>
        </div>
      </div>
      <div className={style.ti__notes}>
        <span>Refund request for invoice </span>
        <Link
          className={style.ti__invoice}
          to={`/transactions/${refund.invoice_code}`}
        >
          {refund.invoice_code}
        </Link>
      </div>
      <div className={style.ti__body}>
        <Image
          src={refund.image_url}
          alt="refund"
          width={100}
          className={style.ti__body__img}
        />
        <p className={style.ti__body__reason}>{refund.reason}</p>
      </div>
    </Card>
  );
};

export default RefundItem;
